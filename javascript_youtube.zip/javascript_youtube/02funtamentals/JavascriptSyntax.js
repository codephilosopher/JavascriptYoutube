/*

Whitespace
Whitespace refers to characters that provide the space between other characters. JavaScript has the following whitespace:

Carriage return
Space
New Line
tab

*/

// The following JavaScript code doesn’t use whitespace:


let formatted = true; if (formatted) {console.log('The code is easy to read');}

// break	case	catch
// continue	debugger	default
// else	export	extends
// function	if	import
// new	return	super
// throw	try	null
// void	while	with
// class	delete	finally
// in	switch	typeof
// yield	const	do
// for	instanceof	this
// var		

/*

Identifiers
An identifier is a name you choose for variables, parameters, functions, classes, etc. An identifier name starts with a letter (a-z, or A-Z), an underscore(_), or a dollar sign ($) and is followed by a sequence of characters including (a-z, A-Z), numbers (0-9), underscores (_), and dollar signs ($).

Note that the letter is not limited to the ASCII character and may include extended ASCII or Unicode though not recommended.

Identifiers are case-sensitive. For example, the message is different from the Message.

*/


/*

Summary
Use whitespace including carriage return, space, newline, and tab to format the code. The JavaScript engine ignores the whitespace.
Use a semicolon (;) to terminate a simple statement.
Use the curly braces ({}) to form a block that groups one or more simple statements.
A single-line comment starts with \/\/ followed by a text. A block comment begins with \/* and ends with *\/. The JavaScript engine also ignores the comments.
Identifiers are names that you choose for variables, functions, classes, etc.
Do not use the reserved keywords and reserved words for identifiers.

*/

