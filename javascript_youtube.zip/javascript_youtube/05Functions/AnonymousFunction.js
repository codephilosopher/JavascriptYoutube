// declaring a anonymous function

(function () {
    console.log("hi There!");
 });

 // invoking a anonymous function

 (function () {
    console.log("hi There!");
 })();


 //Arrow functions