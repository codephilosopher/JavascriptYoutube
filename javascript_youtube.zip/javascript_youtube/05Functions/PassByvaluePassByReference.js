// pass by value; value is passed // stack in stack

function square(x) {
    x = x * x;
    return x;
}

let y = 10;
let result = square(y);

console.log(result); // 100 
console.log(y); // 10 -- no change


// pass ny reference address is passed // stored in heap


let a = {
    a : 5
};

console.log(a);

let b = (obj) => {
    obj.a = 6
};

b(a);

console.log(a);