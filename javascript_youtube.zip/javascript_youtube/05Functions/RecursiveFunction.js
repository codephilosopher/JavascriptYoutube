let recursive =  (n) => {
    if (n <= 1) {
        return 0;
    } else {
        console.log(n);
        recursive(n-1);
    }
}

recursive(6);