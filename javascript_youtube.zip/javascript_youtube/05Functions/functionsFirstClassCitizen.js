/*

Functions are first-class citizens in JavaScript.
You can pass functions to other functions as arguments, return them from other functions as values, and store them in variables.

*/


/*

Storing functions in variables
Functions are first-class citizens in JavaScript. In other words, you can treat functions like values of other types.

*/

function add(a, b) {
    return a + b;
}

let sum = add; // add will ne another type


// Alternatively, we can all the add() function via the sum variable like this:

let result = sum(10,20);


// Passing a function to another function

function add(a, b) {
    return a + b;
}

let sum1 = add;

function average(a, b, fn) {
    return fn(a, b) / 2;
}

let result1 = average(10, 20, sum1);

console.log(result1);

// Returning functions from functions

let a = function()  {
    return function()  {
        return "say something!"
    }
}

console.log(a()());